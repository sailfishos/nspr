/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#include "prtypes.h"

extern PRIntn my_global;

PR_IMPLEMENT(PRIntn) My_GetValue() { return my_global; }
